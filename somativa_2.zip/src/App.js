import Rotas from './rotas';
import './App.css';

function App() {
  return (
    <div className="App">
      <Rotas/>
   
    </div>
  );
}

export default App;
